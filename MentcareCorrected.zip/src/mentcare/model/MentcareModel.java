package mentcare.model;

public class MentcareModel {
public MentcareModel(String firstName, String lastName, String streetAdress, String city, String state, String age,
			String height, String weight, String arrivalDate, String expectedOuttakeDate, String treatment,
			String doctorID, String medicinePrescribed, String meetingLocation) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		StreetAdress = streetAdress;
		City = city;
		State = state;
		Age = age;
		Height = height;
		Weight = weight;
		ArrivalDate = arrivalDate;
		ExpectedOuttakeDate = expectedOuttakeDate;
		Treatment = treatment;
		DoctorID = doctorID;
		MedicinePrescribed = medicinePrescribed;
		MeetingLocation = meetingLocation;
	}
private String firstName;
private String lastName;
private String StreetAdress;
private String City;
private String State;
private String Age;
private String Height;
private String Weight;
private String ArrivalDate;
private String ExpectedOuttakeDate;
private String Treatment;
private String DoctorID;
private String MedicinePrescribed;
private String MeetingLocation;
private String Allergies;
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getStreetAdress() {
	return StreetAdress;
}
public void setStreetAdress(String streetAdress) {
	StreetAdress = streetAdress;
}
public String getCity() {
	return City;
}
public void setCity(String city) {
	City = city;
}
public String getState() {
	return State;
}
public void setState(String state) {
	State = state;
}
public String getAge() {
	return Age;
}
public void setAge(String age) {
	Age = age;
}
public String getHeight() {
	return Height;
}
public void setHeight(String height) {
	Height = height;
}
public String getWeight() {
	return Weight;
}
public void setWeight(String weight) {
	Weight = weight;
}
public String getArrivalDate() {
	return ArrivalDate;
}
public void setArrivalDate(String arrivalDate) {
	ArrivalDate = arrivalDate;
}
public String getExpectedOuttakeDate() {
	return ExpectedOuttakeDate;
}
public void setExpectedOuttakeDate(String expectedOuttakeDate) {
	ExpectedOuttakeDate = expectedOuttakeDate;
}
public String getTreatment() {
	return Treatment;
}
public void setTreatment(String treatment) {
	Treatment = treatment;
}
public String getDoctorID() {
	return DoctorID;
}
public void setDoctorID(String doctorID) {
	DoctorID = doctorID;
}
public String getMedicinePrescribed() {
	return MedicinePrescribed;
}
public void setMedicinePrescribed(String medicinePrescribed) {
	MedicinePrescribed = medicinePrescribed;
}
public String getMeetingLocation() {
	return MeetingLocation;
}
public void setMeetingLocation(String meetingLocation) {
	MeetingLocation = meetingLocation;
	
}
}

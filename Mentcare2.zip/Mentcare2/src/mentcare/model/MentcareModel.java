package mentcare.model;

public class MentcareModel {
	private String firstName;
	private String lastName;
	private String StreetAdress;
	private String City;
	private String State;
	private int Age;
	private int Height;
	private int Weight;
	private String ArrivalDate;
	private String ExpectedOuttakeDate;
	private String Treatment;
	private int DoctorNo;
	private int MedicinePrescribed;
	private int MeetingLocation;
	//private String Allergies;
	private String Gender;



public MentcareModel(String firstName, String lastName, String streetAdress, String city, String state, int age,
			int height, int weight, String gender, String arrivalDate, String expectedOuttakeDate, String treatment,
			int doctorno, int medicinePrescribed, int meetingLocation) {
		super();
	//	this.PatientId = PatientId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.StreetAdress = streetAdress;
		this.City = city;
		this.State = state;
		this.Age = age;
		this.Height = height;
		this.Weight = weight;
		this.Gender = gender;
		this.ArrivalDate = arrivalDate;
		this.ExpectedOuttakeDate = expectedOuttakeDate;
		this.Treatment = treatment;
		this.DoctorNo = doctorno;
		this.MedicinePrescribed = medicinePrescribed;
		this.MeetingLocation = meetingLocation;

}

public String getGender() {
	return Gender;
}

public void setGender(String gender) {
	Gender = gender;
}



public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getStreetAdress() {
	return StreetAdress;
}
public void setStreetAdress(String streetAdress) {
	StreetAdress = streetAdress;
}
public String getCity() {
	return City;
}
public void setCity(String city) {
	City = city;
}
public String getState() {
	return State;
}
public void setState(String state) {
	State = state;
}
public int getAge() {
	return Age;
}
public void setAge(int age) {
	Age = age;
}
public int getHeight() {
	return Height;
}
public void setHeight(int height) {
	Height = height;
}
public int getWeight() {
	return Weight;
}
public void setWeight(int weight) {
	Weight = weight;
}
public String getArrivalDate() {
	return ArrivalDate;
}
public void setArrivalDate(String arrivalDate) {
	ArrivalDate = arrivalDate;
}
public String getExpectedOuttakeDate() {
	return ExpectedOuttakeDate;
}
public void setExpectedOuttakeDate(String expectedOuttakeDate) {
	ExpectedOuttakeDate = expectedOuttakeDate;
}
public String getTreatment() {
	return Treatment;
}
public void setTreatment(String treatment) {
	Treatment = treatment;
}
public int getDoctorNo() {
	return DoctorNo;
}
public void setDoctorNo(int doctorno) {
	DoctorNo = doctorno;
}
public int getMedicinePrescribed() {
	return MedicinePrescribed;
}
public void setMedicinePrescribed(int medicinePrescribed) {
	MedicinePrescribed = medicinePrescribed;
}
public int getMeetingLocation() {
	return MeetingLocation;
}
public void setMeetingLocation(int meetingLocation) {
	MeetingLocation = meetingLocation;

}
}

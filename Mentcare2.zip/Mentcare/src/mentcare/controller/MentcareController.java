package mentcare.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

import application.DatabaseConfig;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import mentcare.model.Poll;

public class MentcareController {
	//These instance variables are used to create new poll objects
    @FXML private TextField Fname;
    @FXML private TextField Lname;
    @FXML private TextField Astreet;
    @FXML private TextField Acity;
    @FXML private TextField Astate;
    @FXML private TextField Azipcode;
    @FXML private TextField Bdate;
    @FXML private TextField Height;
    @FXML private TextField Gender;
    @FXML private TextField Weight;
    @FXML private TextField Adate;
    @FXML private TextField Edate;
    @FXML private TextField Treatment;
    @FXML private TextField Doctor;
    @FXML private TextField Mprescribed;
    @FXML private TextField Mlocation;
    @FXML private Button Register;
    @FXML private TextField Allergies; // Need to update, changed to TEXTBOXES

    public void AddNew()
    {

    }

		  System.out.println("Hello wolrsdsdfdsf");
        Poll poll = new Poll(txtFirstname.getText(),
                                      txtLastname.getText(),
                                      txtState.getText(),
                                      txtParty.getText());

        System.out.println(poll.toString());

        String query = "insert into poll " + "(firstName, lastName, state, party)"
				+ "values(?,?,?,?)";

		try (Connection conn = DatabaseConfig.getConnection();
				PreparedStatement insertpoll = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);) {

			insertpoll.setString(1, poll.getFirstName());
			insertpoll.setString(2, poll.getLastName());
			insertpoll.setString(3, poll.getState());
			insertpoll.setString(4, poll.getState());
			// get the number of return rows
			int affectedRow = insertpoll.executeUpdate();

			if (affectedRow == 1) {
				System.out.println("Operation is successful");
				txtFirstname.setText("");
				txtLastname.setText("");
				txtState.setText("");
				txtParty.setText("");

			}

		} catch (Exception e) {
			System.out.println("Status: operation failed due to "+e);

		}

		}

}

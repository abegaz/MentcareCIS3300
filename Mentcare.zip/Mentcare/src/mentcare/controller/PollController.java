package mentcare.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

import application.DatabaseConfig;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import mentcare.model.Poll;

public class PollController {
	//These instance variables are used to create new poll objects
    @FXML private TextField txtFirstname;
    @FXML private TextField txtLastname;
    @FXML private TextField txtState;
    @FXML private TextField txtParty;

	public void touchRegister()
    {

		  System.out.println("Hello wolrsdsdfdsf");
        Poll poll = new Poll(txtFirstname.getText(),
                                      txtLastname.getText(),
                                      txtState.getText(),
                                      txtParty.getText());

        System.out.println(poll.toString());

        String query = "insert into poll " + "(firstName, lastName, state, party)"
				+ "values(?,?,?,?)";

		try (Connection conn = DatabaseConfig.getConnection();
				PreparedStatement insertpoll = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);) {

			insertpoll.setString(1, poll.getFirstName());
			insertpoll.setString(2, poll.getLastName());
			insertpoll.setString(3, poll.getState());
			insertpoll.setString(4, poll.getState());
			// get the number of return rows
			int affectedRow = insertpoll.executeUpdate();

			if (affectedRow == 1) {
				System.out.println("Operation is successful");
				txtFirstname.setText("");
				txtLastname.setText("");
				txtState.setText("");
				txtParty.setText("");

			}

		} catch (Exception e) {
			System.out.println("Status: operation failed due to "+e);

		}

		}

}
